package jpcap;

/** This class represents datalink layer packet. */
public abstract class DatalinkPacket
{
}
